import {Component} from '@angular/core';
import {DatePipe} from "@angular/common";


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  favoriteMovie = "Lord of the Rings";

  datePipe: DatePipe = new DatePipe('en-US');

  employees: Employee[] = [
    {
      id: 1,
      name: "Ram",
      salary: 20000,
      permanent: true,
      department: {
        id: 1,
        name: "cse"
      },
      skill: [
        {
          id: 1,
          name: 'C#'
        }
      ],
      dateOfBirth: new Date()
    }
  ]

}


interface Employee {
  id: number;
  name: string;
  salary: number;
  permanent: boolean;
  department: Department;
  skill: Skill[];
  dateOfBirth: Date;
}

interface Department {
  id: number;
  name: string;
}

interface Skill {
  id: number;
  name: string;
}
